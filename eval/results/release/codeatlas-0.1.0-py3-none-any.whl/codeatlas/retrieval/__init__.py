"""Repository context retrieval."""
